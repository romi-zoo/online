const button = document.getElementById("enterButton");
const entrance = document.getElementById("entrance");

button.addEventListener("click", () => {
  entrance.classList.add("entering");

  // Temporary destination until the zoo map/first habitat is built.
  setTimeout(() => {
    window.location.href = "zoo.html";
  }, 850);
});
